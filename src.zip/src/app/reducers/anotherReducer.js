const initialState = {};

const anotherReducer = (state = initialState, action) => {
  switch (action.type) {
    default:
      return state;
  }
};

export default anotherReducer;
